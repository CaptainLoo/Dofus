﻿using System;
using System.Collections.Generic;
using Google.Protobuf;
using PacketDotNet;
using SharpPcap;
using Com.Ankama.Dofus.Server.Game.Protocol;
using Com.Ankama.Dofus.Server.Connection.Protocol;

class Program
{
    private static Dictionary<string, List<byte>> bufferMap = new();
    private static List<string> connectionIPList = new() { "34.249.146.47", "54.74.22.247" };

    static void Main(string[] args)
    {
        // Initialisation des buffers
        bufferMap["ConnectionServerClientToServer"] = new List<byte>();
        bufferMap["ConnectionServerServerToClient"] = new List<byte>();
        bufferMap["GameServerClientToServer"] = new List<byte>();
        bufferMap["GameServerServerToClient"] = new List<byte>();

        Console.WriteLine("Initialisation du sniffer...");
        var devices = CaptureDeviceList.Instance;

        if (devices.Count == 0)
        {
            Console.WriteLine("Aucune interface réseau trouvée.");
            return;
        }

        // Choisir l'interface réseau (par défaut : en0)
        var device = devices.FirstOrDefault(d => d.Name == "en0");
        if (device == null)
        {
            Console.WriteLine("Interface réseau 'en0' introuvable. Veuillez vérifier votre configuration.");
            return;
        }

        Console.WriteLine($"Écoute sur : {device.Description}");

        // Configuration de l'écoute
        device.OnPacketArrival += Device_OnPacketArrival;
        device.Open(DeviceModes.Promiscuous);
        device.StartCapture();

        Console.WriteLine("Appuie sur Entrée pour arrêter...");
        Console.ReadLine();

        device.StopCapture();
        device.Close();
    }

    private static void Device_OnPacketArrival(object sender, PacketCapture e)
    {
        var rawPacket = e.GetPacket();
        var packet = Packet.ParsePacket(rawPacket.LinkLayerType, rawPacket.Data);
        var ethernetPacket = packet.Extract<EthernetPacket>();

        if (ethernetPacket != null && ethernetPacket.PayloadPacket is IPv4Packet ipPacket)
        {
            HandleIPv4Packet(ipPacket);
        }
    }

    private static void HandleIPv4Packet(IPv4Packet ipPacket)
    {
        if (ipPacket.PayloadPacket is TcpPacket tcpPacket)
        {
            HandleDofusPacket(ipPacket, tcpPacket);
        }
    }

    private static void HandleDofusPacket(IPv4Packet ipPacket, TcpPacket tcpPacket)
    {
        // Filtrer uniquement les paquets pour le port 5555
        if (tcpPacket.DestinationPort != 5555 && tcpPacket.SourcePort != 5555)
        {
            return;
        }

        if (tcpPacket.PayloadData.Length == 0)
        {
            return;
        }

        var serverType = connectionIPList.Contains(ipPacket.SourceAddress.ToString()) ? ServerType.ConnectionServer : ServerType.GameServer;
        IMessage message = serverType == ServerType.ConnectionServer ? new LoginMessage() : new GameMessage();

        var direction = tcpPacket.SourcePort == 5555 ? Direction.ServerToClient : Direction.ClientToServer;
        var bufferId = $"{serverType}{direction}";

        if (!bufferMap.ContainsKey(bufferId))
        {
            bufferMap[bufferId] = new List<byte>();
        }

        var partialBuffer = bufferMap[bufferId];
        partialBuffer.AddRange(tcpPacket.PayloadData);

        Console.WriteLine($"[DEBUG] Paquet reçu : Direction = {direction}, ServerType = {serverType}");
        Console.WriteLine($"[DEBUG] Payload brut : {BitConverter.ToString(tcpPacket.PayloadData)}");

        while (partialBuffer.Count > 0)
        {
            int sizeLength = 0;
            int size = (int)DecodeVarint(partialBuffer.ToArray(), ref sizeLength);

            if (size == 0 || size > partialBuffer.Count - sizeLength)
                break;

            var payload = partialBuffer.GetRange(sizeLength, size).ToArray();
            partialBuffer.RemoveRange(0, sizeLength + size);

            if (!Protocol.DecodeMessage(payload, message))
            {
                Console.WriteLine($"[ERREUR] Échec du décodage du message : {BitConverter.ToString(payload)}");
                continue;
            }

            ProcessMessage(direction, serverType, message);
        }

        bufferMap[bufferId] = partialBuffer;
    }

    private static void ProcessMessage(Direction direction, ServerType serverType, IMessage message)
    {
        string msgType = "UNK";
        string msgName = "Unknown";

        if (serverType == ServerType.ConnectionServer && message is LoginMessage cm)
        {
            switch (cm.ContentCase)
            {
                case LoginMessage.ContentOneofCase.Request:
                    msgType = "REQ";
                    msgName = cm.Request.ToString();
                    break;

                case LoginMessage.ContentOneofCase.Response:
                    msgType = "RES";
                    msgName = cm.Response.ToString();
                    break;

                case LoginMessage.ContentOneofCase.Event:
                    msgType = "EVT";
                    msgName = cm.Event.ToString();
                    break;
            }
        }
        else if (serverType == ServerType.GameServer && message is GameMessage gm)
        {
            switch (gm.ContentCase)
            {
                case GameMessage.ContentOneofCase.Request:
                    msgType = "REQ";
                    msgName = gm.Request.Content.TypeUrl;
                    break;

                case GameMessage.ContentOneofCase.Response:
                    msgType = "RES";
                    msgName = gm.Response.Content.TypeUrl;
                    break;

                case GameMessage.ContentOneofCase.Event:
                    msgType = "EVT";
                    msgName = gm.Event.Content.TypeUrl;
                    break;
            }
        }

        Protocol.PrettyPrintMessage(message);

        Console.ForegroundColor = direction == Direction.ClientToServer ? ConsoleColor.Cyan : ConsoleColor.Blue;
        Console.WriteLine($"[{direction}] [{msgType}] {msgName}");
        Console.ResetColor();
    }

    private static ulong DecodeVarint(byte[] buffer, ref int bytesRead)
    {
        ulong value = 0;
        int shift = 0;

        for (int i = 0; i < buffer.Length; i++)
        {
            byte b = buffer[i];
            value |= (ulong)(b & 0x7F) << shift;
            bytesRead++;

            if ((b & 0x80) == 0)
                return value;

            shift += 7;
            if (shift >= 64)
                throw new InvalidOperationException("Varint trop long.");
        }

        return 0;
    }
}